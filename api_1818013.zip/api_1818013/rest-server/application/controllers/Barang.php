<?php

use chriskacerguis\RestServer\RestController;

class Barang extends RestController
{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('barang_model', 'brg');
    }

    public function index()
    {
        $data["barang"] = $this->brg->get_all();
        $this->load->view("dash/dash_header");
        $this->load->view("dash/v_barang");
        $this->load->view("dash/dash_footer");
    }
    public function index_get()
    {

        $id = $this->get('kd_batik');
        if ($id === null) {
            $p = $this->get('page');
            $p = (empty($p) ? 1 : $p);
            $total_data = $this->brg->count();
            $total_page = ceil($total_data / 10);
            $start = ($p - 1) * 10;
            $list = $this->brg->get(null, 10, $start);
            if ($list) {
                $data = [
                    'status' => true,
                    'page' => $p,
                    'total_data' => $total_data,
                    'total_page' => $total_page,
                    'data' => $list
                ];
            } else {
                $data = [
                    'status' => false,
                    'msg' => 'Data tak ditemukan'
                ];
            }
            $this->response($data, RestController::HTTP_OK);
        } else {
            $data = $this->brg->get($id);
            if ($data) {
                $this->response(['status' => true, 'data' => $data], RestController::HTTP_OK);
            } else {
                $this->response(['status' => false, 'msg' => $id, 'Data tak ditemukan'], RestController::HTTP_NOT_FOUND);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'kd_batik' => $this->post('kd_batik'),
            'nama_batik' => $this->post('nama_batik'),
            'ukuran' => $this->post('ukuran'),
            'harga' => $this->post('harga'),
            'stok' => $this->post('stok')
        ];
        $simpan = $this->brg->add($data);
        if ($simpan['status']) {
            $this->response(['status' => true, 'msg' => $simpan['data'] . ' Data telah ditambahkan'], RestController::HTTP_CREATED);
        } else {
            $this->response(['status' => false, 'msg' => $simpan['msg']], RestController::HTTP_INTERNAL_ERROR);
        }
    }

    public function index_put()
    {
        $data = [
            'kd_batik' => $this->put('kd_batik'),
            'nama_batik' => $this->put('nama_batik'),
            'ukuran' => $this->put('ukuran'),
            'harga' => $this->put('harga'),
            'stok' => $this->put('stok')
        ];
        $kd_batik = $this->put('kd_batik');
        if($kd_batik===null){
            $this->response(['status' => false, 'msg' => ' Masukkan Kode yang akan diubah'], RestController::HTTP_BAD_REQUEST);  
        }
        $simpan = $this->brg->update($kd_batik, $data);
        if ($simpan['status']) {
            $status=(int)$simpan['data'];
            if($status > 0)
            $this->response(['status' => true, 'msg' => $simpan['data'] . ' Data telah dirubah'], RestController::HTTP_OK);
            else
            $this->response(['status' => false, 'msg' => 'Tak ada data yang dirubah'], RestController::HTTP_INTERNAL_ERROR);
        } else {
            $this->response(['status' => false, 'msg' => $simpan['msg']], RestController::HTTP_INTERNAL_ERROR);
        }
    }

    public function index_delete(){
        $kd_batik = $this->delete('kd_batik');
        if($kd_batik===null){
            $this->response(['status' => false, 'msg' => ' Masukkan Kode yang akan dihapus'], RestController::HTTP_BAD_REQUEST);  
        }
        $delete = $this->brg->delete($kd_batik);
        if ($delete['status']) {
            $status=(int)$delete['data'];
            if($status > 0)
            $this->response(['status' => true, 'msg' => $kd_batik . ' Data telah dihapus'], RestController::HTTP_OK);
            else
            $this->response(['status' => false, 'msg' => 'Tak ada data yang dihapus'], RestController::HTTP_INTERNAL_ERROR);
        } else {
            $this->response(['status' => false, 'msg' => $delete['msg']], RestController::HTTP_INTERNAL_ERROR);
        }
    }
}
