<div class="container">
    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('flash'); ?>"></div>
    <?php if ($this->session->flashdata('flash')) : ?>
    <!-- <div class="row mt-3">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Data barang <strong>berhasil</strong> <?= $this->session->flashdata('flash'); ?>.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div> -->
    <?php endif; ?>

    <div class="row mt-3">
        <div class="col-md-6">
            <a href="<?= base_url(); ?>barang/tambah" class="btn btn-primary">Tambah
                Data barang</a>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-6">
            <form action="" method="post">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari data Barang" name="keyword">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-6">
            <h3>Daftar Barang</h3>
            <?php if (empty($tb_barang)) : ?>
                <div class="alert alert-danger" role="alert">
                data barang tidak ditemukan.
                </div>
            <?php endif; ?>
            <ul class="list-group">
                <?php foreach ($tb_barang as $brg) : ?>
                <li class="list-group-item">
                    <?= $brg['kd_batik']; ?>
                    <a href="<?= base_url(); ?>barang/hapus/<?= $brg['kd_batik']; ?>"
                        class="badge badge-danger float-right tombol-hapus">Hapus</a>
                    <a href="<?= base_url(); ?>barang/ubah/<?= $brg['kd_batik']; ?>"
                        class="badge badge-success float-right">Ubah</a>
                    <a href="<?= base_url(); ?>barang/detail/<?= $brg['kd_batik']; ?>"
                        class="badge badge-primary float-right">Detail</a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</div>