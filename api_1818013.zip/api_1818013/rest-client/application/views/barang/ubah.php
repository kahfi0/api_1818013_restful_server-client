<div class="container">

    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Form Ubah Data Barang
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="hidden" name="kd_batik" value="<?= $tb_barang['kd_batik']; ?>">
                        <div class="form-group">
                            <label for="nama_batik">Nama Batik</label>
                            <input type="text" name="nama_batik" class="form-control" id="nama_batik" value="<?= $tb_barang['nama_batik']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama_batik'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="ukuran">Ukuran</label>
                            <input type="text" name="ukuran" class="form-control" id="ukuran" value="<?= $tb_barang['ukuran']; ?>">
                            <small class="form-text text-danger"><?= form_error('ukuran'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga" value="<?= $tb_barang['harga']; ?>">
                            <small class="form-text text-danger"><?= form_error('harga'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input type="text" name="stok" class="form-control" id="stok" value="<?= $tb_barang['stok']; ?>">
                            <small class="form-text text-danger"><?= form_error('stok'); ?></small>
                        </div>
                        <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah Data</button>
                        <a href="<?= base_url(); ?>barang" class="btn btn-primary ">Kembali</a>
                    </form>
                </div>
            </div>


        </div>
    </div>

</div>