<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Detail Data Barang
                </div>
                <div class="card-body">
                    <h4 class="card-title">Nama Batik : <?= $tb_barang['nama_batik']; ?></h4>
                    <p class="card-text">Ukuran : <?= $tb_barang['ukuran']; ?></p>
                    <p class="card-text">Harga : <?= $tb_barang['harga']; ?></p>
                    <p class="card-text">Stok : <?= $tb_barang['stok']; ?></p>
                    <a href="<?= base_url(); ?>barang" class="btn btn-primary">Kembali</a>
                </div>
            </div>
        
        </div>
    </div>
</div>