<?php 
use GuzzleHttp\Client;

class Barang_model extends CI_model {

    private $_client;

    public function __construct()
    {
        $this->_client = new Client([
            'base_uri' => 'http://localhost:8080/api_1818013/rest-server/index.php/',
            'auth' => ['kahfi','12345']
        ]);

    }

    public function getAllBarang()
    {
        //return $this->db->get('tb_barang')->result_array();

        $response = $this->_client->request('GET', 'barang', [
            'query' => [
                'wpu-key' => '1818013'
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['data'];
    }

    public function getBarangById($kd_batik)
    {
        //return $this->db->get_where('tb_barang', ['kd_batik' => $kd_batik])->row_array();

        $response = $this->_client->request('GET', 'barang', [
            'query' => [
                'wpu-key' => '1818013',
                'kd_batik' => $kd_batik
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['data'][0];

    }

    public function tambahDataBarang()
    {
        $data = [
            "kd_batik" => $this->input->post('kd_batik', true),
            "nama_batik" => $this->input->post('nama_batik', true),
            "ukuran" => $this->input->post('ukuran', true),
            "harga" => $this->input->post('harga', true),
            "stok" => $this->input->post('stok', true),
            'wpu-key' => '1818013'
        ];

        //$this->db->insert('tb_barang', $data);
        $response = $this->_client->request('POST', 'barang', [
            'form_params' => $data
                
        ]);
        $result = json_decode($response->getBody()->getContents(), true);
        return $result;

    }

    public function hapusDataBarang($kd_batik)
    {
        // $this->db->where('id', $id);
        //$this->db->delete('tb_barang', ['kd_batik' => $kd_batik]);
        $response = $this->_client->request('DELETE', 'barang', [
            'form_params' => [
                
                'kd_batik' => $kd_batik,
                'wpu-key' => '1818013'

            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);
        return $result;
    }


    public function ubahDataBarang()
    {
        $data = [
            "kd_batik" => $this->input->post('kd_batik', true),
            "nama_batik" => $this->input->post('nama_batik', true),
            "ukuran" => $this->input->post('ukuran', true),
            "harga" => $this->input->post('harga', true),
            "stok" => $this->input->post('stok', true),
            'wpu-key' => '1818013'
        ];

        //$this->db->where('kd_batik', $this->input->post('kd_batik'));
        //$this->db->update('tb_barang', $data);
        $response = $this->_client->request('PUT', 'barang', [
            'form_params' => $data
                
        ]);
        $result = json_decode($response->getBody()->getContents(), true);
        return $result;

    }

    public function cariDataBarang()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('kd_batik', $keyword);
        $this->db->or_like('nama_batik', $keyword);
        $this->db->or_like('ukuran', $keyword);
        $this->db->or_like('harga', $keyword);
        $this->db->or_like('stok', $keyword);
        return $this->db->get('tb_barang')->result_array();
    }
}