<?php

class Barang extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['judul'] = 'Daftar Barang';
        $data['tb_barang'] = $this->Barang_model->getAllBarang();
        if( $this->input->post('keyword') ) {
            $data['tb_barang'] = $this->Barang_model->cariDataBarang();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('barang/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Barang';
        $this->form_validation->set_rules('kd_batik', 'Kode Batik', 'required');
        $this->form_validation->set_rules('nama_batik', 'Nama Batik', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
        //$this->form_validation->set_rules('nrp', 'NRP', 'required|numeric');
        //$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('barang/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Barang_model->tambahDataBarang();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('barang');
        }
    }

    public function hapus($kode_batik)
    {
        $this->Barang_model->hapusDataBarang($kode_batik);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('barang');
    }

    public function detail($kode_batik)
    {
        $data['judul'] = 'Detail Data Barang';
        $data['tb_barang'] = $this->Barang_model->getBarangById($kode_batik);
        $this->load->view('templates/header', $data);
        $this->load->view('barang/detail', $data);
        $this->load->view('templates/footer');
    }

    public function ubah($kode_batik)
    {
        $data['judul'] = 'Form Ubah Data Barang';
        $data['tb_barang'] = $this->Barang_model->getBarangById($kode_batik);
        //$data['jurusan'] = ['Teknik Informatika', 'Teknik Mesin', 'Teknik Planologi', 'Teknik Pangan', 'Teknik Lingkungan'];
        $this->form_validation->set_rules('nama_batik', 'Nama Batik', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('barang/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Barang_model->ubahDataBarang();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('barang');
        }
    }

}
